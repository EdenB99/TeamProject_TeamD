using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapTileData : MonoBehaviour
{
    public MapData MapData { get; set; }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IActivatable
{
    /// <summary>
    /// ��� �Լ�
    /// </summary>
    bool ItemActive(Vector2 pos);

}

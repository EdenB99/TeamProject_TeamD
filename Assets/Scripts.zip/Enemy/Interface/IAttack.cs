using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IAttack
{
    /// <summary>
    /// ���ݷ� ������Ƽ
    /// </summary>
    uint AttackPower { get; }
}
